CREATE PROCEDURE FixDividendTxnTypes(IN in_testMode  TINYINT(1), IN in_oldTxnType INT, IN in_newTxnType INT,
                                     IN in_performer BIGINT, IN in_note TEXT, IN in_description TEXT)
  BEGIN
    
    DECLARE loop_cntr, fixed_cntr INT DEFAULT 0;
    DECLARE num_rows INT DEFAULT 0;  
    DECLARE fix_amount, fix_endingBalance, prev_endingBalance DECIMAL(19,2) DEFAULT 0; 
    DECLARE no_more_rows, fixed_account BIT DEFAULT FALSE;     
    
    DECLARE c_utID, c_accountID, c_divID, c_auditTrailID BIGINT;
    DECLARE c_createdDate, c_completedDate, c_recordedDate DATETIME;
    DECLARE c_amount DECIMAL(19,2);
    DECLARE c_millis, c_typeByID INT;
    DECLARE c_failed BIT;
        
    DECLARE note, description TEXT;

    
    DECLARE AUDIT_TRAIL_ID, AUDIT_TASK_ID BIGINT;
    
    
    
    DECLARE cur1 CURSOR FOR 
          select ut.id as utID, ut.amount, ut.accountID, ut.createdDate, ut.completedDate, ut.recordedDate, ut.failed, ut.typeByID, ut.auditTrailID, d.id as divID from DividendAllocations da 
        JOIN UserTransactions ut on da.parentTransactionID = ut.id
            JOIN Dividends d on d.id = da.dividendID and d.id in (222,220)
            where ut.accountID>12 and ut.failed=true 
            
            and ut.typeByID=in_oldTxnType
            order by ut.accountID asc, ut.completedDate desc, ut.milliseconds desc;
                        
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND
            SET no_more_rows = TRUE;

    
    
    OPEN cur1;
    select FOUND_ROWS() into num_rows;
    the_loop: LOOP
        FETCH cur1 INTO c_utID, c_amount, c_accountID, c_createdDate, c_completedDate, c_recordedDate, c_failed, c_typeByID, c_auditTrailID, c_divID;

        
        
        
        IF no_more_rows THEN
           CLOSE cur1;
              LEAVE the_loop;
        END IF;
            
        
            
        START TRANSACTION;
        BEGIN
                
              set note = in_note;
              set description = CONCAT(in_description, ". Adjusting txnType of failed dividend ",c_utID,", account: ",c_accountID," to txnType ",in_newTxnType);
              
              select c_utID, c_amount, c_accountID, c_createdDate, c_completedDate, c_recordedDate, c_divID, in_performer, note, description;
            
              IF(in_testMode <> true) THEN
                
                IF(c_auditTrailID is null) THEN
                    insert into AuditTrails (id) values (null); set AUDIT_TRAIL_ID=LAST_INSERT_ID();
                   ELSE
                        set AUDIT_TRAIL_ID=c_auditTrailID;
                   END IF;
                   
                   insert into AuditTasks (date,note,detail,srcIP,performerID) values (now(),note, description,"67.244.27.159",in_performer); SET AUDIT_TASK_ID:=LAST_INSERT_ID();
                   insert into AuditEvents (action,srcObject,auditTrailID,orderedCollectionIndex,auditTaskID) 
                            values ('U',CONCAT("UserTranasction[id=",c_utID,",txnTypeID=",c_typeByID,"]"),AUDIT_TRAIL_ID,0,AUDIT_TASK_ID);

                   
                   update UserTransactions set typeByID=in_newTxnType, auditTrailID=AUDIT_TRAIL_ID where id=c_utID limit 1;
               END IF;
         COMMIT;
         END;
         
         SET loop_cntr = loop_cntr + 1;
    END LOOP the_loop;
    
    select num_rows, loop_cntr;       
END;
