CREATE PROCEDURE FixDividendFeeCreditDescription(IN in_testMode       TINYINT(1), IN in_singleAccountID BIGINT,
                                                 IN in_newDescription VARCHAR(128), IN in_performer BIGINT,
                                                 IN in_note           TEXT, IN in_description TEXT)
  BEGIN
    
    DECLARE loop_cntr, fixed_cntr INT DEFAULT 0;
    DECLARE num_rows INT DEFAULT 0;
    DECLARE no_more_rows, fixed_account BIT DEFAULT FALSE;     
    
    DECLARE c_utID, c_accountID, c_transactionDocumentID, c_auditTrailID BIGINT;
    DECLARE c_amount DECIMAL(19,2);
    DECLARE c_description VARCHAR(128);
    DECLARE c_failed BIT;
        
    DECLARE auditNote, auditDescription TEXT;

    
    DECLARE AUDIT_TRAIL_ID, AUDIT_TASK_ID, UT_ID BIGINT;
    
    
    
    DECLARE cur1 CURSOR FOR 
            SELECT utID, amount, accountID, description as txnDesc, transactionDocumentID, failed, auditTrailID FROM
        (
            select ut.id as utID, ut.amount, ut.description, ut.accountID, d.id as divID, ut.failed, ut.transactionDocumentID, ut.auditTrailID from DividendAllocations da
            JOIN UserTransactions ut on da.parentTransactionID = ut.id
            JOIN Dividends d on d.id = da.dividendID and d.id in (222,220)
            JOIN Accounts a on ut.accountID = a.id and a.id not in 
            (
                select t.accountID as accountID from 
                (
                    select ut.id as utID, ut.amount, ut.description, ut.accountID, ut.createdDate, ut.completedDate, ut.recordedDate, ut.failed, d.id as divID from DividendAllocations da 
                    JOIN UserTransactions ut on da.parentTransactionID = ut.id
                    JOIN Dividends d on d.id = da.dividendID and d.id in (222,220)
                    where ut.accountID>12 and ut.failed=true
                       order by ut.accountID asc, ut.completedDate desc, ut.milliseconds desc
                 ) t
                 join Accounts a on t.accountID = a.id
                 group by accountID
                 having count(utID) >= 2 and IF(in_singleAccountID > 0, accountID = in_singleAccountID, 1=1)
             )
            where ut.accountID>12
            order by ut.completedDate desc, ut.accountID asc
        ) t
        GROUP by t.accountID, t.divID
        HAVING t.amount<.25 and t.failed=0
        ORDER BY t.amount desc;

                        
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND
            SET no_more_rows = TRUE;
            
    
    
    OPEN cur1;
    select FOUND_ROWS() into num_rows;
    select num_rows;
    
    
    
    the_loop: LOOP
        FETCH cur1 INTO c_utID, c_amount, c_accountID, c_description, c_transactionDocumentID, c_failed, c_auditTrailID;
    
        
        
        
        IF no_more_rows THEN
           CLOSE cur1;
              LEAVE the_loop;
        END IF;
        
        START TRANSACTION;
        BEGIN
                
              set auditNote = in_note;
              set auditDescription = CONCAT(in_description, ". Changing transaction description from ", c_description," to ", in_newDescription, " and nulling out transactionDocumentID.");
              
              select c_utID, c_accountID, c_description, c_transactionDocumentID, c_auditTrailID, in_performer, auditNote, auditDescription;
            
              IF(in_testMode <> true) THEN
                
                IF(c_auditTrailID is null) THEN
                    insert into AuditTrails (id) values (null); set AUDIT_TRAIL_ID=LAST_INSERT_ID();
                   ELSE
                        set AUDIT_TRAIL_ID=c_auditTrailID;
                   END IF;
                   
                   insert into AuditTasks (date,note,detail,srcIP,performerID) values (now(),auditNote, auditDescription,"67.244.27.159",in_performer); SET AUDIT_TASK_ID:=LAST_INSERT_ID();
                   insert into AuditEvents (action,srcObject,auditTrailID,orderedCollectionIndex,auditTaskID) 
                            values ('U',CONCAT("UserTransction[typeByID=4, description=",c_description,", transactionDocumentID=",c_transactionDocumentID,"]"),AUDIT_TRAIL_ID,0,AUDIT_TASK_ID);

                   
                   UPDATE UserTransactions SET transactionDocumentID = NULL, description = in_newDescription, typeByID=6, auditTrailID = AUDIT_TRAIL_ID WHERE id = c_utID LIMIT 1;
                   
               END IF;
         COMMIT;
         END;
         
         SET loop_cntr = loop_cntr + 1;
    END LOOP the_loop;
    
    select num_rows, loop_cntr;       
END;
