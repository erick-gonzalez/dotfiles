CREATE PROCEDURE AuditTransactionDocument(IN in_testMode TINYINT(1), IN in_txnID BIGINT, IN in_performer BIGINT,
                                          IN in_note     TEXT, IN in_description TEXT)
  BEGIN
    
    DECLARE loop_cntr, fixed_cntr INT DEFAULT 0;
    DECLARE num_rows INT DEFAULT 0;  
    DECLARE no_more_rows BIT DEFAULT FALSE;     
    
    DECLARE c_utID, c_transactionDocumentID, c_auditTrailID BIGINT;
        
    DECLARE note, description TEXT;

    
    DECLARE AUDIT_TRAIL_ID, AUDIT_TASK_ID BIGINT;
    DECLARE ORDERED_COLLECTION_INDEX INT;
    
    
    
    DECLARE cur1 CURSOR FOR 
          select id, transactionDocumentID, auditTrailID from UserTransactions where id = in_txnID;
                        
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND
            SET no_more_rows = TRUE;

    
    
    OPEN cur1;
    select FOUND_ROWS() into num_rows;
    the_loop: LOOP
        FETCH cur1 INTO c_utID, c_transactionDocumentID, c_auditTrailID;
        
        

        
        
        
        IF no_more_rows THEN
           CLOSE cur1;
              LEAVE the_loop;
        END IF;
            
        START TRANSACTION;
        BEGIN
                
              set note = in_note;
              set description = CONCAT(in_description, ". Auditing TransactionID ", c_utID, ", nulling out original transactionDocumentID ", c_transactionDocumentID, ".");
              
              select c_utID, c_transactionDocumentID, c_auditTrailID, in_performer, note, description;
            
              IF(in_testMode <> true) THEN
                
                IF(c_auditTrailID is null) THEN
                    insert into AuditTrails (id) values (null); set AUDIT_TRAIL_ID=LAST_INSERT_ID();
                    set @ORDERED_COLLECTION_INDEX = 0;
                   ELSE
                        set AUDIT_TRAIL_ID=c_auditTrailID;
                        select @ORDERED_COLLECTION_INDEX := orderedCollectionIndex + 1 from AuditEvents where auditTrailID = AUDIT_TRAIL_ID order by orderedCollectionIndex desc limit 1;
                   END IF;
                   
                   insert into AuditTasks (date,note,detail,srcIP,performerID) values (now(),note, description,"69.20.84.236",in_performer); SET AUDIT_TASK_ID:=LAST_INSERT_ID();
                   insert into AuditEvents (action,srcObject,auditTrailID,orderedCollectionIndex,auditTaskID) 
                            values ('U',CONCAT("UserTranasction[id=",c_utID,", transactionDocumentID=",c_transactionDocumentID,"]"),AUDIT_TRAIL_ID,@ORDERED_COLLECTION_INDEX,AUDIT_TASK_ID);

                   
                   update UserTransactions set transactionDocumentID=NULL, auditTrailID=AUDIT_TRAIL_ID where id=c_utID limit 1;
               END IF;
         COMMIT;
         END;
         
         SET loop_cntr = loop_cntr + 1;
    END LOOP the_loop;
    
    select num_rows, loop_cntr;       
END;
