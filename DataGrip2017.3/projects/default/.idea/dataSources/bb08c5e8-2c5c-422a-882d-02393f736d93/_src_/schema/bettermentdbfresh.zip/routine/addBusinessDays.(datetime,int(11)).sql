CREATE FUNCTION addBusinessDays(startDate DATETIME, numDays INT)
  RETURNS DATETIME
  BEGIN
	DECLARE nextBDay DATETIME;
	DECLARE count INT;
	SET nextBDay = startDate;
	SET count = numDays;
	WHILE count > 0 DO
		IF isBankHolidayOrWeekend(nextBDay) = 0 THEN SET count = (count-1);
		END IF;
		SET nextBDay = DATE_ADD(nextBDay, INTERVAL 1 DAY);
	END WHILE;

	WHILE isBankHolidayOrWeekend(nextBDay) DO SET nextBDay = DATE_ADD(nextBDay, INTERVAL 1 DAY);
	END WHILE;
	RETURN nextBDay;
END;
