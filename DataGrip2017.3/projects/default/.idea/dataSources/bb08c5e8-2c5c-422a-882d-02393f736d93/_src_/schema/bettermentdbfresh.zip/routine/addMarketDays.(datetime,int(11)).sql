CREATE FUNCTION addMarketDays(startDate DATETIME, numDays INT)
  RETURNS DATETIME
  BEGIN
	DECLARE nextMarketDay DATETIME;
	DECLARE count INT;
	SET nextMarketDay = startDate;
	SET count = 0;

	WHILE count < numDays DO
		SET nextMarketDay = DATE_ADD(nextMarketDay, INTERVAL 1 DAY);
		IF isMarketHolidayOrWeekend(nextMarketDay) = 0 THEN SET count = (count + 1);
		END IF;
	END WHILE;

	RETURN nextMarketDay;
END;
