CREATE TRIGGER AutomaticDeposits_after_upd_trig
AFTER UPDATE ON AutomaticDeposits
FOR EACH ROW
  BEGIN
  INSERT INTO AutomaticDepositsHistory (
  		automaticDepositID,
		createdDate,
		amount,
		enabled,
		ignored,
		accountID,
		modifiedByUserID,
		auditTrailID,
		typeByID,
		lastUpdate,
		lastEnabled,
		lastPlanChange,
		transactionDate1,
		transactionDate2
		)
	VALUES (
		new.id,
		new.createdDate,
		new.amount,
		new.enabled,
		new.ignored,
		new.accountID,
		new.modifiedByUserID,
		new.auditTrailID,
		new.typeByID,
		new.lastUpdate,
		new.lastEnabled,
		new.lastPlanChange,
		new.transactionDate1,
		new.transactionDate2
	);
END;
