CREATE FUNCTION AuditInParallel(in_audit_trail_id BIGINT, in_audit_task_id BIGINT, in_src_object LONGTEXT,
                                in_action         VARCHAR(1))
  RETURNS BIGINT
  BEGIN
    DECLARE out_audit_trail_id BIGINT;
    DECLARE COLLECTION_INDEX INT;

    IF in_audit_trail_id IS NULL THEN
        INSERT INTO AuditTrails (id) VALUES (NULL);
        SET out_audit_trail_id:=LAST_INSERT_ID();
        SET COLLECTION_INDEX:=0;
    ELSE
        SET out_audit_trail_id:=in_audit_trail_id;
        SET COLLECTION_INDEX:= (SELECT MAX(orderedCollectionIndex)+1 FROM AuditEvents WHERE auditTrailID = out_audit_trail_id);
    END IF;

    INSERT INTO AuditEvents (ACTION, srcObject, auditTrailID, orderedCollectionIndex, auditTaskID) VALUES (in_action, in_src_object, out_audit_trail_id, COLLECTION_INDEX, in_audit_task_id);

    RETURN (out_audit_trail_id);
END;
