CREATE PROCEDURE SnapshotCashLedgerPositionEntries(IN in_datetime     DATETIME, IN in_snapshot_type CHAR,
                                                   IN in_force_record CHAR(5))
  BEGIN
    DECLARE start_time TIMESTAMP;
    DECLARE num_rows INT DEFAULT 0;
    DECLARE snapshot_type CHAR(1) DEFAULT 'D';
    DECLARE datetime_millis BIGINT;
    DECLARE last_updated BIGINT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SELECT 'Snapshot failed. Rolling back.';
        ROLLBACK;
    END;

    START TRANSACTION;


    SET start_time=NOW();

    SELECT CONCAT(start_time,' SnapshotCashLedgerPositionEntries called with args ',in_datetime,' , ',in_snapshot_type,' , ',in_force_record);

    
    SELECT CONCAT(NOW(),' Converting in_datetime to millis');
    SET datetime_millis = toMillis(in_datetime);

    SELECT 'Started transaction';

    
    SELECT CONCAT(NOW(),' Validating snapshot_type, only accept 'D' for Daily and 'R' for ReserveComp, otherwise throw an error');

    IF(in_snapshot_type NOT IN ('D','R')) THEN
        SIGNAL SQLSTATE '02000'
            SET MESSAGE_TEXT = 'in_snapshot_type must be: (D) Daily or (R) ReserveComp';
    ELSE
        
        SELECT CONCAT(NOW(),' Converting snapshot_type to utf8mb4 encoding to ensure collation does not fail');

        SET snapshot_type = CONVERT(in_snapshot_type USING 'utf8mb4');
    END IF;

    
    IF(snapshot_type = 'D') THEN
        SELECT CONCAT(NOW(),' Snapshot is type D. Deleting any preexisting records from today of type D');
        DELETE FROM HistoricCashLedgerPositionEntries WHERE DATE(createdDateTime)=DATE(in_datetime) AND snapshotType=snapshot_type;
    END IF;

    
    SELECT CONCAT(NOW(),' Determining the latest cash positions per account/location pair as of in_datetime and persist it to our temp table');

    DROP TEMPORARY TABLE IF EXISTS TempCashLedgerSnapshot;

    IF SUBSTRING(in_force_record,1,1)='f' THEN
        SELECT CONCAT(NOW(),' Only adding snapshot records for account-location pairs modified since the last snapshot run');

        SELECT CONCAT(NOW(),' Determining last updated time');
        SET last_updated := COALESCE((SELECT timestampMillis FROM HistoricCashLedgerPositionEntries WHERE snapshotType=snapshot_type ORDER BY timestampMillis DESC LIMIT 1),0);
        SELECT CONCAT(NOW(),' Last updated millis: ',last_updated);

        
        CREATE TEMPORARY TABLE TempCashLedgerSnapshot (
            SELECT oper.accountID, oper.accountLocationID, SUM(IF(oper.failedDateTime IS NULL,oper.settledPositionDelta,0)) AS settledPosition, SUM(IF(oper.failedDateTime IS NULL,oper.unsettledPositionDelta,0)) AS unsettledPosition, MAX(oper.timestampMillis) AS timestampMillis
            FROM CashLedgerPositionEntries oper
            JOIN (
                SELECT DISTINCT clpe.accountID, clpe.accountLocationID
                    FROM CashLedgerPositionEntries clpe
                    WHERE last_modified_datetime >= FROM_UNIXTIME(last_updated /1000)
                ) recent
                ON recent.accountID = oper.accountID AND recent.accountLocationID=oper.accountLocationID
                WHERE oper.timestampMillis <=  datetime_millis
            GROUP BY oper.accountID, oper.accountLocationID
        );

    ELSE
        SELECT CONCAT(NOW(),' Adding snapshot records for all account-location pairs regardless of when they last updated');

        CREATE TEMPORARY TABLE TempCashLedgerSnapshot (
            SELECT oper.accountID, oper.accountLocationID, SUM(oper.settledPositionDelta) AS settledPosition, SUM(oper.unsettledPositionDelta) AS unsettledPosition, MAX(oper.timestampMillis) AS timestampMillis
            FROM CashLedgerPositionEntries oper
                WHERE oper.failedDateTime IS NULL
                    AND oper.timestampMillis <=  datetime_millis
            GROUP BY oper.accountID, oper.accountLocationID
            );
    END IF;

    
    SELECT CONCAT(NOW(),' Adding an index to speed up querying further down in the proc');

    ALTER TABLE TempCashLedgerSnapshot ADD INDEX TempCashLedgerSnapshot_idx (accountID, accountLocationID, settledPosition, unsettledPosition);

    SELECT count(*) FROM TempCashLedgerSnapshot INTO num_rows;

    IF num_rows > 0 THEN

        
        SELECT CONCAT(NOW(),' Persisting latest positions to the Historic table');

        INSERT INTO HistoricCashLedgerPositionEntries(accountID, accountLocationID, settledPosition, unsettledPosition, createdDateTime, timestampMillis, snapshotType)
            SELECT temp.accountID, temp.accountLocationID, COALESCE (temp.settledPosition,0), COALESCE(temp.unsettledPosition,0), in_datetime, datetime_millis, snapshot_type
                FROM TempCashLedgerSnapshot temp;

    END IF;
    DROP TEMPORARY TABLE IF EXISTS TempCashLedgerSnapshot;
    COMMIT;

     
    SELECT CONCAT(NOW(),' Created ',num_rows,' entries in ',TIMEDIFF(NOW(),start_time), ' from SnapshotCashLedgerPositionEntries call with args ',in_datetime,' , ',in_snapshot_type,' , ',in_force_record,' at ',start_time,'. Previous run was found at ',last_updated);
END;
