CREATE TRIGGER TR_Tickers_InsertPreventLongSettlement
BEFORE INSERT ON Tickers
FOR EACH ROW
  BEGIN
          IF NEW.settlementPeriod > 3
          THEN
               SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'Cannot add or update row: code does not support tickers with more than 3 day settlment cycle';
          END IF;
     END;
