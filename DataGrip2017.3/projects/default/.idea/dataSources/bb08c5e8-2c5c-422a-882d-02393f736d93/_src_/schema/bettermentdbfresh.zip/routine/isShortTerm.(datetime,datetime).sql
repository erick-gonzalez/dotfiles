CREATE FUNCTION isShortTerm(purchaseDateTime DATETIME, currentDateTime DATETIME)
  RETURNS TINYINT(1)
  BEGIN
    DECLARE yearAfterPurchaseYear INT;
    DECLARE isLeapYear BOOLEAN;
    DECLARE isAfterDayFiftyNine BOOLEAN;
    DECLARE adjustedPurchaseDate DATE;
    DECLARE result BOOLEAN;

    SELECT YEAR(DATE(purchaseDateTime)) + 1 INTO yearAfterPurchaseYear;

    SELECT IF((yearAfterPurchaseYear % 4 = 0) AND (yearAfterPurchaseYear % 100 != 0) OR (yearAfterPurchaseYear % 400 = 0), 1, 0) INTO isLeapYear;

    SELECT IF(DAYOFYEAR(purchaseDateTime) >= 59, 1, 0) INTO isAfterDayFiftyNine;

    SELECT IF(isLeapYear AND isAfterDayFiftyNine, DATE_ADD(DATE(purchaseDateTime), INTERVAL 1 DAY), DATE(purchaseDateTime)) INTO adjustedPurchaseDate;

    SELECT IF(TIMESTAMPDIFF(DAY, adjustedPurchaseDate, currentDateTime) < 366, TRUE, FALSE) INTO result;

    RETURN result;
END;
