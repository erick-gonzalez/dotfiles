CREATE PROCEDURE EndingBalanceAdjuster(IN in_testMode  TINYINT(1), IN in_src_tableName VARCHAR(128),
                                       IN in_performer BIGINT, IN in_note TEXT, IN in_description TEXT)
  BEGIN
    
    
    DECLARE loop_cntr, fixed_cntr, rollback_cntr INT DEFAULT 0;
    DECLARE num_rows, num_rows2, rid1 INT DEFAULT 0;  
    DECLARE no_more_rows, no_more_rows2 BIT DEFAULT FALSE;  
    DECLARE do_rollback BIT DEFAULT FALSE;   

    
    DECLARE c_id, c_accountID, c_divID, c_id1, c_id2, c_auditTrailID1, c_auditTrailID2 BIGINT;
    DECLARE c_createdDate, c_completedDate, c_recordedDate DATETIME;
    DECLARE c_amount, c_amount1, c_amount2, c_endingBalance1, c_endingBalance2, c_calcNextBalance, c_delta DECIMAL(19,2);
    DECLARE c_millis, c_rid1, c_rid2, c_typeByID1, c_typeByID2 INT;
    DECLARE c_failed1, c_failed2 BIT;

    
    DECLARE AUDIT_TRAIL_ID, AUDIT_TASK_ID BIGINT;
    DECLARE note, description TEXT;

    
    DECLARE fix_amount, fix_endingBalance, prev_endingBalance DECIMAL(19,2) DEFAULT 0; 
    
    
    DECLARE fixed_account_id BIGINT;
    DECLARE fixed_account_ids, neg_balance_accounts TEXT;
    DECLARE delim CHAR(1);
    
    
    DECLARE cur1 CURSOR FOR SELECT * FROM TempSourceTableData09101982; 
                        
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND
            SET no_more_rows = TRUE;
            
    
    set neg_balance_accounts = "";
    set fixed_account_ids = "";
    set fixed_account_id = 0;
            
    
    
    DROP TABLE IF EXISTS TempSourceTableData09101982;
    set @query = CONCAT("CREATE TEMPORARY TABLE TempSourceTableData09101982 as (  
            select id as c_id, accountID as c_accountID, createdDate as c_createdDate, completedDate as c_completedDate, recordedDate as c_recordedDate, milliseconds as c_millis from ", in_src_tableName, ")");
            
        PREPARE stmt from @query; 
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    
    select * from TempSourceTableData09101982;

    
    
    OPEN cur1;
    select FOUND_ROWS() into num_rows;
    set @query="";
    the_loop: LOOP
            FETCH cur1 INTO c_id, c_accountID, c_createdDate, c_completedDate, c_recordedDate, c_millis;

            
            
            
        IF no_more_rows THEN
                CLOSE cur1;
                LEAVE the_loop;
         END IF;
         
         
         
            
         START TRANSACTION;
            BEGIN
                
                set note = in_note;
                set description = CONCAT(in_description, ". Adjusting account: ",c_accountID,".");
                
            
            set @rid1:=0;
            
            DROP TABLE IF EXISTS TmpAccountTransactions1;
            CREATE TEMPORARY TABLE TmpAccountTransactions1 as ( 
                select @rid1:=@rid1+1 as rid, ut.id, ut.typeByID, ut.amount, ut.endingBalance, ut.description, ut.createdDate, ut.completedDate, ut.recordedDate, ut.failed, ut.auditTrailID 
                from UserTransactions ut 
                where ut.accountID=c_accountID and (UNIX_TIMESTAMP(ut.completedDate)*1000 + ut.milliseconds) >= (UNIX_TIMESTAMP(c_completedDate)*1000 + c_millis) 
                order by ut.completedDate asc, ut.milliseconds asc
            );
            
            DROP TABLE IF EXISTS TmpAccountTransactions2;
            CREATE TEMPORARY TABLE TmpAccountTransactions2 (
                select * from TmpAccountTransactions1
            );
            
            SET no_more_rows2 = FALSE;
            
            INNER_BLOCK: begin
                DECLARE cur2 CURSOR FOR 
                    select 
                    t1.rid as rid1, t1.id as id1, t1.amount as amount1, t1.endingBalance as endingBalance1, t1.typeByID as typeByID1, t1.failed as failed1, t1.auditTrailID as auditTrailID1, 
                    t2.rid as rid2, t2.id as id2, t2.amount as amount2, t2.endingBalance as endingBalance2, t2.typeByID as typeByID2, t2.failed as failed2, t2.auditTrailID as auditTrailID2,
                    (t1.endingBalance+t2.amount) as calcNextBalance, ((t2.amount+t1.endingBalance) - t2.endingBalance) as delta 
                    from TmpAccountTransactions1 t1 inner join TmpAccountTransactions2 t2 on t1.rid+1=t2.rid;

                
                
                DECLARE CONTINUE HANDLER FOR NOT FOUND
                        SET no_more_rows2 = TRUE;
                                        
                
                
                OPEN cur2;
                select FOUND_ROWS() into num_rows2;
                
                the_loop2: LOOP
                    FETCH cur2 INTO 
                        c_rid1, c_id1, c_amount1, c_endingBalance1, c_typeByID1, c_failed1, c_auditTrailID1,
                        c_rid2, c_id2, c_amount2, c_endingBalance2, c_typeByID2, c_failed2, c_auditTrailID2,
                        c_calcNextBalance, c_delta;
                
                 
                     
                     
                    IF no_more_rows2 THEN
                        CLOSE cur2;
                        LEAVE the_loop2;
                    END IF;
                    
                    set fix_amount = c_amount2;
                    set fix_endingBalance = c_endingBalance2;
                    
                    IF(prev_endingBalance = 0) THEN
                        set prev_endingBalance = c_endingBalance1;
                    END IF;
                    
                    
                    
                    IF((prev_endingBalance + c_amount2)  <> c_endingBalance2) THEN
                        
                        IF(c_failed2 = true or c_typeByID2 = 20) THEN
                            IF(c_endingBalance2 = c_endingBalance1) THEN
                                
                                ITERATE the_loop2;
                            ELSE
                                set fix_endingBalance = prev_endingBalance;
                            END IF;
                        ELSEIF(c_typeByID2 = 2) THEN
                            
                            set fix_amount = c_endingBalance2 - prev_endingBalance;
                        ELSE
                            
                            set fix_endingBalance = prev_endingBalance + c_amount2;
                        END IF;
                        
                        select CONCAT("Discrepancy detected for account ", c_accountID,", txn ",c_id2,", type ",c_typeByID2,". Updating amount (",c_amount2," to ",fix_amount,
                            "), endingBalance(",c_endingBalance2," to ",fix_endingBalance,")") as debug;
                         set fixed_account_id = c_accountID;
                    
                        IF(in_testMode <> true) THEN

                            
                            IF(c_auditTrailID2 is null) THEN
                                insert into AuditTrails (id) values (null); set AUDIT_TRAIL_ID=LAST_INSERT_ID();
                            ELSE
                                set AUDIT_TRAIL_ID=c_auditTrailID2;
                            END IF;
                            insert into AuditTasks (date,note,detail,srcIP,performerID) values (now(),note, description,"67.244.27.159",in_performer); SET AUDIT_TASK_ID:=LAST_INSERT_ID();
                            insert into AuditEvents (action,srcObject,auditTrailID,orderedCollectionIndex,auditTaskID) 
                                values ('U',CONCAT("UserTranasction[id=",c_id2,",amount=",fix_amount,",endingBalance=",fix_endingBalance,"]"),AUDIT_TRAIL_ID,0,AUDIT_TASK_ID);

                            
                            update UserTransactions set amount=fix_amount, endingBalance=fix_endingBalance, auditTrailID=AUDIT_TRAIL_ID where id=c_id2;
                        END IF;
                    
                        
                        
                        
                        IF(fix_endingBalance < 0) THEN
                            SET rollback_cntr = rollback_cntr+1;
                            SET do_rollback = TRUE;
                            SET delim = IF(LENGTH(neg_balance_accounts) > 0,",","");
                            SET neg_balance_accounts = CONCAT(neg_balance_accounts,delim,c_accountID);
                            
                            CLOSE cur2;
                            LEAVE the_loop2;
                        END IF;                    
                    END IF; 
                    set prev_endingBalance = fix_endingBalance;
              END LOOP the_loop2;
            end INNER_BLOCK;    
            
            
            set prev_endingBalance = 0; 
            
            IF (do_rollback = TRUE) THEN
                ROLLBACK;
            ELSE
                COMMIT;
            END IF;
           SET do_rollback = FALSE;

        END;
            
            
         SET loop_cntr = loop_cntr + 1;
         
            IF(fixed_account_id > 0) THEN
                SET fixed_cntr = fixed_cntr+1;
                SET delim = IF(LENGTH(fixed_account_ids) > 0, ",","");
                SET fixed_account_ids = CONCAT(fixed_account_ids, delim, fixed_account_id);
                SET fixed_account_id = 0;
            END IF;     
    END LOOP the_loop;
        
        select num_rows, loop_cntr, fixed_cntr, rollback_cntr, neg_balance_accounts, fixed_account_ids;     
END;
