CREATE TRIGGER Accounts_update_accountTypeID_to_accountType_tr
BEFORE UPDATE ON Accounts
FOR EACH ROW
  BEGIN
    
    CASE NEW.accountType
        WHEN 'UNKNOWN'              THEN SET NEW.accountTypeID = '-';
        WHEN 'SYSTEM'               THEN SET NEW.accountTypeID = 's';
        WHEN 'INVESTING'            THEN SET NEW.accountTypeID = 'i';
        WHEN 'ROTH_IRA'             THEN SET NEW.accountTypeID = 'r';
        WHEN 'TRADITIONAL_IRA'      THEN SET NEW.accountTypeID = 't';
        WHEN 'OMNIBUS'              THEN SET NEW.accountTypeID = 'o';
        WHEN 'ACH_DEPOSITS'         THEN SET NEW.accountTypeID = 'a';
        WHEN 'ACH_WITHDRAWALS'      THEN SET NEW.accountTypeID = 'w';
        WHEN 'PAYMENTS'             THEN SET NEW.accountTypeID = 'p';
        WHEN 'DIVIDENDS'            THEN SET NEW.accountTypeID = 'd';
        WHEN 'ADVISORY_FEES'        THEN SET NEW.accountTypeID = 'f';
        WHEN 'OPERATIONAL_CHARGES'  THEN SET NEW.accountTypeID = 'c';
        WHEN 'MICRO_VERIFICATIONS'  THEN SET NEW.accountTypeID = 'v';
        WHEN 'MTG_OPS'              THEN SET NEW.accountTypeID = 'm';
        WHEN 'MISCELLANEOUS_OPS'    THEN SET NEW.accountTypeID = 'u';
        WHEN 'ACH_RETURNS'          THEN SET NEW.accountTypeID = 'h';
        ELSE SET NEW.accountTypeID = NEW.accountTypeID;
    END CASE;

    
    CASE NEW.accountTypeID
        WHEN '-' THEN SET NEW.accountType = 'UNKNOWN';
        WHEN 's' THEN SET NEW.accountType = 'SYSTEM';
        WHEN 'i' THEN SET NEW.accountType = 'INVESTING';
        WHEN 'r' THEN SET NEW.accountType = 'ROTH_IRA';
        WHEN 't' THEN SET NEW.accountType = 'TRADITIONAL_IRA';
        WHEN 'o' THEN SET NEW.accountType = 'OMNIBUS';
        WHEN 'a' THEN SET NEW.accountType = 'ACH_DEPOSITS';
        WHEN 'w' THEN SET NEW.accountType = 'ACH_WITHDRAWALS';
        WHEN 'p' THEN SET NEW.accountType = 'PAYMENTS';
        WHEN 'd' THEN SET NEW.accountType = 'DIVIDENDS';
        WHEN 'f' THEN SET NEW.accountType = 'ADVISORY_FEES';
        WHEN 'c' THEN SET NEW.accountType = 'OPERATIONAL_CHARGES';
        WHEN 'v' THEN SET NEW.accountType = 'MICRO_VERIFICATIONS';
        WHEN 'm' THEN SET NEW.accountType = 'MTG_OPS';
        WHEN 'u' THEN SET NEW.accountType = 'MISCELLANEOUS_OPS';
        WHEN 'h' THEN SET NEW.accountType = 'ACH_RETURNS';
        ELSE SET NEW.accountType = NEW.accountType;
    END CASE;
END;
