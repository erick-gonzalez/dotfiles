CREATE PROCEDURE FixDividendCreateAdjustment(IN in_testMode  TINYINT(1), IN in_oldTxnType INT, IN in_newTxnType INT,
                                             IN in_performer BIGINT, IN in_note TEXT, IN in_description TEXT)
  BEGIN
    
    DECLARE loop_cntr, fixed_cntr INT DEFAULT 0;
    DECLARE num_rows INT DEFAULT 0;  
    DECLARE fix_amount, fix_endingBalance, prev_endingBalance DECIMAL(19,2) DEFAULT 0; 
    DECLARE no_more_rows, fixed_account BIT DEFAULT FALSE;     
    
    DECLARE c_utID, c_accountID, c_divID, c_auditTrailID, c_dividendID BIGINT;
    DECLARE c_createdDate, c_completedDate, c_recordedDate DATETIME;
    DECLARE c_amount DECIMAL(19,2);
    DECLARE c_millis, c_typeByID INT;
    DECLARE c_failed BIT;
    DECLARE c_txnDesc VARCHAR(128);
        
    DECLARE note, description TEXT;

    
    DECLARE AUDIT_TRAIL_ID, AUDIT_TASK_ID, UT_ID BIGINT;
    
    
    
    DECLARE cur1 CURSOR FOR 
    select ut.id, ut.amount, ut.description, ut.accountID, da.dividendID 
            from UserTransactions ut join DividendAllocations da on da.parentTransactionID=ut.id
        where ut.accountID in 
        (
            select accountID  from (
                select ut.id as utID, ut.amount, ut.description, ut.accountID, ut.createdDate, ut.completedDate, ut.recordedDate, ut.failed, d.id as divID from DividendAllocations da 
                JOIN UserTransactions ut on da.parentTransactionID = ut.id
                JOIN Dividends d on d.id = da.dividendID and d.id in (222,220)
                where ut.accountID>12 and ut.failed=true
                order by ut.accountID asc, ut.completedDate desc, ut.milliseconds desc
             ) t
            group by accountID
            having count(utID) > 2
            order by accountID
         )
        and ut.typeByID = in_oldTxnType and date(ut.createdDate) >= '2013-04-08'
        and ut.failed = 1
        group by ut.accountID, ut.description
        having count(ut.description) > 1
        order by ut.accountID, ut.createdDate;
                        
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND
            SET no_more_rows = TRUE;

    
    
    OPEN cur1;
    select FOUND_ROWS() into num_rows;
    select num_rows;
    the_loop: LOOP
        FETCH cur1 INTO c_utID, c_amount, c_txnDesc, c_accountID, c_dividendID;

        
        
        
        IF no_more_rows THEN
           CLOSE cur1;
              LEAVE the_loop;
        END IF;
            
        START TRANSACTION;
        BEGIN
                
              set note = in_note;
              set description = CONCAT(in_description, ". Creating a new adjustment for an incorrectly failed dividend ",c_utID,", account: ",c_accountID," of type txnType ",in_newTxnType, ".");
              
              select c_utID, c_amount, c_txnDesc, c_accountID, c_dividendID, in_performer, note, description;
            
              IF(in_testMode <> true) THEN
                
                IF(c_auditTrailID is null) THEN
                    insert into AuditTrails (id) values (null); set AUDIT_TRAIL_ID=LAST_INSERT_ID();
                   ELSE
                        set AUDIT_TRAIL_ID=c_auditTrailID;
                   END IF;
                   
                   insert into AuditTasks (date,note,detail,srcIP,performerID) values (now(),note, description,"67.244.27.159",in_performer); SET AUDIT_TASK_ID:=LAST_INSERT_ID();
                   insert into AuditEvents (action,srcObject,auditTrailID,orderedCollectionIndex,auditTaskID) 
                            values ('C',CONCAT("UserTranasction[txnTypeID=",in_newTxnType,"]"),AUDIT_TRAIL_ID,0,AUDIT_TASK_ID);

                   
                   INSERT INTO `UserTransactions` (`id`, `txType`, `createdDate`, `completedDate`, `settledDate`, `recordedDate`, `milliseconds`, `accountID`, `pending`, 
                                    `failed`, `transactionDocumentID`, `amount`, `description`, `endingBalance`, `changeDesc`, `readyToComplete`, `typeByID`, `auditTrailID`)
                    VALUES
                    (NULL, 'AcctTxn', CURRENT_TIMESTAMP, NULL, NULL, NULL, 0, c_accountID, 1, 
                                     0, NULL, c_amount, c_txnDesc, NULL, NULL, 0, in_newTxnType, AUDIT_TRAIL_ID); SET UT_ID:=LAST_INSERT_ID();
                   
                   insert into AuditTrails (id) values (null); set AUDIT_TRAIL_ID=LAST_INSERT_ID();
                   insert into AuditEvents (action,srcObject,auditTrailID,orderedCollectionIndex,auditTaskID) 
                            values ('C',CONCAT("DividendAllocation[dividendID=",c_dividendID,", parentTransactionID=",UT_ID,"]"),AUDIT_TRAIL_ID,0,AUDIT_TASK_ID);
                            
                   INSERT INTO `DividendAllocations` (`id`, `dividendID`, `parentTransactionID`, `createdDateTime`, `auditTrailID`)
                VALUES
                    (NULL, c_dividendID, UT_ID, CURRENT_TIMESTAMP, AUDIT_TRAIL_ID);
                
                
                insert into AuditTrails (id) values (null); set AUDIT_TRAIL_ID=LAST_INSERT_ID();
                   insert into AuditEvents (action,srcObject,auditTrailID,orderedCollectionIndex,auditTaskID) 
                            values ('C',CONCAT("TransactionReversalMapping[initialUT=",c_utID,", reversalUT=",UT_ID,"]"),AUDIT_TRAIL_ID,0,AUDIT_TASK_ID);

                INSERT INTO `TransactionReversalMappings` (`id`, `transactionMappingTypeID`, `initialAchTransactionID`, `reversalAchTransactionID`, `reversalUserTransactionID`, `initialUserTransactionID`, `initialIndividualOmnibusAccountTransactionID`, `reversalIndividualOmnibusAccountTransactionID`, `createdDateTime`, `auditTrailID`)
                VALUES
                    (NULL, 'a', NULL, NULL, UT_ID, c_utID, NULL, NULL, CURRENT_TIMESTAMP, AUDIT_TRAIL_ID);

               END IF;
         COMMIT;
         END;
         
         SET loop_cntr = loop_cntr + 1;
    END LOOP the_loop;
    
    select num_rows, loop_cntr;       
END;
