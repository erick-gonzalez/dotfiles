CREATE TRIGGER B4bTransactions_after_ins_trig
AFTER INSERT ON LegalAccount401kContributions
FOR EACH ROW
  BEGIN
  INSERT INTO B4bTransactions (
    id,
    aggregateB4bTransactionID,
    userTransactionID,
    b4bLegalAccountTransactionID,
    transactionType,
    failedDateTime,
    last_modified_datetime
  )
  VALUES (
    new.id,
    new.aggregate401kContributionID,
    new.userTransactionID,
    new.b4bLegalAccountTransactionID,
    new.transactionType,
    new.failedDateTime,
    new.last_modified_datetime
  );
END;
