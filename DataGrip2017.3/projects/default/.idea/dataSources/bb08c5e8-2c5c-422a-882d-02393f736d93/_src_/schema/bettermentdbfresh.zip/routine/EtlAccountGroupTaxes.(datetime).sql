CREATE PROCEDURE EtlAccountGroupTaxes(IN in_as_of_date DATETIME)
  BEGIN

    DECLARE v_price_group_id BIGINT;
    DECLARE v_baseline_tax_year INT;
    DECLARE v_year_start DATETIME;
    DECLARE v_current_year, v_year_to_recalc_from INT;


    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET FOREIGN_KEY_CHECKS = 1;
        ROLLBACK;
        RESIGNAL;
    END;

    SET FOREIGN_KEY_CHECKS = 0;

    SET v_baseline_tax_year = 2014;
    SET v_current_year = YEAR(in_as_of_date);
    SET v_year_to_recalc_from = IF (YEAR(DATE_SUB(in_as_of_date, INTERVAL 31 DAY)) = v_current_year, v_current_year, v_current_year - 1);
    SET v_year_start = STR_TO_DATE(CONCAT(MAKEDATE(v_year_to_recalc_from, 1), ' ', MAKETIME(0, 0, 0)), '%Y-%m-%d %H:%i:%s');

    DROP TEMPORARY TABLE IF EXISTS tmp_latest_prices;
    CREATE TEMPORARY TABLE tmp_latest_prices
    SELECT p.tickerID, p.price, p.date
    FROM  (SELECT DISTINCT tickerID from Prices) distinctTickers
      INNER JOIN Prices p on p.id = (select p2.id from Prices p2 WHERE distinctTickers.tickerID = p2.tickerID and p2.priceTypeByID = 2 order by date desc limit 1);




    
    DROP TEMPORARY TABLE IF EXISTS tmp_tax_effect_row_data;
    CREATE TEMPORARY TABLE tmp_tax_effect_row_data
    SELECT
        tl.accountGroupID,
        COALESCE(YEAR(tl.sellDate), v_current_year) as taxYear,
        tl.tickerID,
        CONCAT(IF (tl.hasRealizedLoss is null, 'UNREALIZED', 'REALIZED'), '_', IF(isShortTerm(tl.adjustedPurchaseDate, COALESCE(tl.sellDate, in_as_of_date)), 'SHORT_TERM', 'LONG_TERM'), '_', IF(COALESCE(tl.sellPrice, p.price) < tl.adjustedCostBasis, 'LOSS', 'GAIN')) AS status,
        SUM(ROUND(ABS((COALESCE(tl.sellPrice, p.price) - tl.adjustedCostBasis)) * tl.shares, 2)) as amount
    FROM TaxLots tl
        INNER JOIN tmp_latest_prices p on tl.tickerID = p.tickerID
    WHERE
        tl.isCurrent = true
        AND (tl.sellDate is null OR tl.sellDate >= v_year_start)
        AND tl.omnibusAccountID = 1
    GROUP BY
        tl.accountGroupID,
        tl.tickerId,
        tl.hasRealizedLoss is null,
        COALESCE(YEAR(tl.sellDate), v_current_year),
        isShortTerm(tl.adjustedPurchaseDate, COALESCE(tl.sellDate, in_as_of_date)),
        COALESCE(tl.sellPrice, p.price) < adjustedCostBasis;



    INSERT INTO AccountGroupTaxSummaries (
      accountGroupID,
      tickerID,
      taxYear,
      lastUpdated,
      realizedLongTermGain,
      realizedLongTermLoss,
      realizedShortTermGain,
      realizedShortTermLoss,
      unrealizedLongTermGain,
      unrealizedLongTermLoss,
      unrealizedShortTermGain,
      unrealizedShortTermLoss
    )
    SELECT
      row_data.accountGroupID,
      row_data.tickerID,
      row_data.taxYear,
      in_as_of_date,
      COALESCE(MAX(CASE WHEN row_data.status = 'REALIZED_LONG_TERM_GAIN' THEN row_data.amount END), 0) as realizedLongTermGain,
      COALESCE(MAX(CASE WHEN row_data.status = 'REALIZED_LONG_TERM_LOSS' THEN row_data.amount END), 0) as realizedLongTermLoss,
      COALESCE(MAX(CASE WHEN row_data.status = 'REALIZED_SHORT_TERM_GAIN' THEN row_data.amount END), 0) as realizedShortTermGain,
      COALESCE(MAX(CASE WHEN row_data.status = 'REALIZED_SHORT_TERM_LOSS' THEN row_data.amount END), 0) as realizedShortTermLoss,
      COALESCE(MAX(CASE WHEN row_data.status = 'UNREALIZED_LONG_TERM_GAIN' THEN row_data.amount END), 0) as unrealizedLongTermGain,
      COALESCE(MAX(CASE WHEN row_data.status = 'UNREALIZED_LONG_TERM_LOSS' THEN row_data.amount END), 0) as unrealizedLongTermLoss,
      COALESCE(MAX(CASE WHEN row_data.status = 'UNREALIZED_SHORT_TERM_GAIN' THEN row_data.amount END), 0) as unrealizedShortTermGain,
      COALESCE(MAX(CASE WHEN row_data.status = 'UNREALIZED_SHORT_TERM_LOSS' THEN row_data.amount END), 0) as unrealizedShortTermLoss
    FROM tmp_tax_effect_row_data row_data
    GROUP BY
      row_data.accountGroupID,
      row_data.taxYear,
      row_data.tickerID
    ON DUPLICATE KEY UPDATE
      lastUpdated=in_as_of_date,
      realizedLongTermGain=VALUES(realizedLongTermGain),
      realizedLongTermLoss=VALUES(realizedLongTermLoss),
      realizedLongTermLossDisallowed=VALUES(realizedLongTermLossDisallowed),
      realizedShortTermGain=VALUES(realizedShortTermGain),
      realizedShortTermLoss=VALUES(realizedShortTermLoss),
      realizedShortTermLossDisallowed=VALUES(realizedShortTermLossDisallowed),
      unrealizedLongTermGain=VALUES(unrealizedLongTermGain),
      unrealizedLongTermLoss=VALUES(unrealizedLongTermLoss),
      unrealizedShortTermGain=VALUES(unrealizedShortTermGain),
      unrealizedShortTermLoss=VALUES(unrealizedShortTermLoss);



    
    DROP TEMPORARY TABLE IF EXISTS tmp_tax_effect_disallowed_row_data;
    CREATE TEMPORARY TABLE tmp_tax_effect_disallowed_row_data
    SELECT
      tl.accountGroupID as accountGroupID,
      YEAR(tl.sellDate) as taxYear,
      tl.tickerID as tickerID,
      IF(isShortTerm(tl.adjustedPurchaseDate, tl.sellDate), 'SHORT_TERM', 'LONG_TERM') AS status,
      SUM(ROUND((tl.adjustedCostBasis - tl.sellPrice) * tl.disallowedLossShares, 2)) as amount
    FROM TaxLots tl
    WHERE
      tl.isCurrent = true
      AND tl.sellDate >= v_year_start
      AND tl.omnibusAccountID = 1
      AND tl.disallowedLossShares > 0
    GROUP BY
      tl.accountGroupID,
      tl.tickerId,
      YEAR(tl.sellDate),
      isShortTerm(tl.adjustedPurchaseDate, tl.sellDate);

    INSERT INTO AccountGroupTaxSummaries (
      accountGroupID,
      tickerID,
      taxYear,
      lastUpdated,
      realizedShortTermLossDisallowed,
      realizedLongTermLossDisallowed
    )
    SELECT
      row_data.accountGroupID,
      row_data.tickerID,
      row_data.taxYear,
      in_as_of_date,
      COALESCE(MAX(CASE WHEN row_data.status = 'SHORT_TERM' THEN row_data.amount END), 0) as realizedShortTermLossDisallowed,
      COALESCE(MAX(CASE WHEN row_data.status = 'LONG_TERM' THEN row_data.amount END), 0) as realizedLongTermLossDisallowed
    FROM tmp_tax_effect_disallowed_row_data row_data
    GROUP BY
      row_data.accountGroupID,
      row_data.taxYear,
      row_data.tickerID
    ON DUPLICATE KEY UPDATE
      lastUpdated=in_as_of_date,
      realizedShortTermLossDisallowed=VALUES(realizedShortTermLossDisallowed),
      realizedLongTermLossDisallowed=VALUES(realizedLongTermLossDisallowed);



    
    INSERT INTO AccountGroupTaxSummaries (
      accountGroupID,
      tickerID,
      taxYear,
      lastUpdated,
      tlhLongTermGain,
      tlhLongTermLoss,
      tlhLongTermLossDisallowed,
      tlhShortTermGain,
      tlhShortTermLoss,
      tlhShortTermLossDisallowed
    )
    SELECT
      ite.accountGroupID,
      t.tickerID,
      v_current_year as taxYear,
      in_as_of_date,
      sum(ite.longTermGain) as longTermGain,
      sum(ite.longTermLoss) as longTermLoss,
      sum(ite.longTermLossDisallowed + ite.longTermLossPermanentlyDisallowed) as longTermLossDisallowed,
      sum(ite.shortTermGain) as shortTermGain,
      sum(ite.shortTermLoss) as shortTermLoss,
      sum(ite.shortTermLossDisallowed + ite.shortTermLossPermanentlyDisallowed) as shortTermLossDisallowed
    FROM IndividualTradeGroupTaxEffects ite
      INNER JOIN IndividualTradeGroups itg on ite.individualTradeGroupID = itg.id
      INNER JOIN Trades t on itg.tradeID = t.id
    WHERE
      ite.transactionTypeByID = 31 
      AND YEAR(itg.completedDate) = v_current_year
    GROUP BY
      ite.accountGroupID,
      t.tickerID,
      YEAR(itg.completedDate)
    ON DUPLICATE KEY UPDATE
      lastUpdated=in_as_of_date,
      tlhLongTermGain=VALUES(tlhLongTermGain),
      tlhLongTermLoss=VALUES(tlhLongTermLoss),
      tlhLongTermLossDisallowed=VALUES(tlhLongTermLossDisallowed),
      tlhShortTermGain=VALUES(tlhShortTermGain),
      tlhShortTermLoss=VALUES(tlhShortTermLoss),
      tlhShortTermLossDisallowed=VALUES(tlhShortTermLossDisallowed);


    
    UPDATE AccountGroupTaxSummaries
    SET
      unrealizedLongTermGain=0,
      unrealizedLongTermLoss=0,
      unrealizedShortTermGain=0,
      unrealizedShortTermLoss=0
    WHERE taxYear <> v_current_year
      AND (unrealizedLongTermGain <> 0 OR unrealizedLongTermLoss <> 0 OR unrealizedShortTermGain <> 0 OR unrealizedShortTermLoss <> 0);


    DROP TEMPORARY TABLE IF EXISTS tmp_tax_effect_row_data;
    DROP TEMPORARY TABLE IF EXISTS tmp_tax_effect_disallowed_row_data;
    DROP TEMPORARY TABLE IF EXISTS tmp_latest_prices;

    SET FOREIGN_KEY_CHECKS = 1;

END;
