CREATE FUNCTION textanycat(text, anynonarray)
  RETURNS text
STABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select $1 || $2::pg_catalog.text
$$;

