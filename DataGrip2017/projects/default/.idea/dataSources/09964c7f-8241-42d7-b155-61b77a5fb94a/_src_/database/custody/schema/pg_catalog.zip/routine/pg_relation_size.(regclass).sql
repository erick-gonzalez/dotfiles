create function pg_catalog.pg_relation_size(regclass) returns bigint
LANGUAGE SQL
AS $$
select pg_catalog.pg_relation_size($1, 'main')
$$;
