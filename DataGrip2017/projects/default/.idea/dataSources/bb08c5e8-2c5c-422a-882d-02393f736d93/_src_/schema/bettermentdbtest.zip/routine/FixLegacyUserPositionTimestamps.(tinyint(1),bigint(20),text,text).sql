CREATE PROCEDURE bettermentdbtest.FixLegacyUserPositionTimestamps(IN in_testMode TINYINT(1), IN in_performer BIGINT,
                                                                  IN in_note     TEXT, IN in_description TEXT)
  BEGIN

    DECLARE loop_cntr INT DEFAULT 0;
    DECLARE num_rows INT DEFAULT 0;
    DECLARE no_more_rows BIT DEFAULT FALSE;

    DECLARE c_auditTrailID, c_badPositionID, c_adjustingID, c_accountID BIGINT;
    DECLARE c_newMilliseconds, c_oldMilliseconds, c_tickerID INT;
    DECLARE c_newDate, c_oldDate DATETIME;

    DECLARE note, description TEXT;

    DECLARE AUDIT_TRAIL_ID, AUDIT_TASK_ID BIGINT;

    
    
    DECLARE cur1 CURSOR FOR
          SELECT up.id as adjustingID, up.date as oldDate, up.milliseconds as oldMilliseconds, badPositionID, newDate, newMilliseconds, up.auditTrailID, up.accountID, up.tickerID
          FROM   UserPositions up
                 INNER JOIN (SELECT `date`           AS newDate,
                                    milliseconds + 1 AS newMilliseconds,
                                    tickerid,
                                    accountid,
                                    id as badPositionID
                             FROM   UserPositions
                             WHERE  id IN ( 1886128, 1885594, 1885142, 1884150, 
                                                1883400, 1883402, 1883196, 1883198,
                                                1883190, 1883192, 1883020, 1883022,
                                                1882694, 1882696, 1881904, 1881906,
                                                1880984, 1880986, 1880672, 1880674,
                                                1880116, 1880118, 1879878, 1879880,
                                                1879512, 1878770, 1877860, 1877862,
                                                1877848, 1877850, 1877606, 1923406,
                                                1922356, 1922358, 1922296, 1922272,
                                                1921866, 1921786, 1921708, 1921584,
                                                1921506, 1921508, 1921494, 1921496,
                                                1921454, 1921392, 1921380, 1921356,
                                                1921092, 1921094, 1921046, 1921022,
                                                1877474, 1877476, 1877438, 1877294,
                                                1877296, 1877270, 1876958, 1876778,
                                                1876646, 1875942, 1875512, 1875500,
                                                1833794, 1833796, 1833658, 1832990,
                                                1832374, 1832326, 1832328, 1832294,
                                                1832296, 1832210, 1832054, 1832056,
                                                1832024, 1831932, 1831934, 1831840,
                                                1831686, 1831544, 1831382, 1831282,
                                                1831284, 1831172, 1830992, 1830860,
                                                1830862, 1830438, 1830090, 1830092,
                                                1829832, 1829834, 1829384, 1829258,
                                                1828800, 1828762, 1828764, 1828660,
                                                1828648, 1828476, 1828332, 1827700,
                                                1827368, 1827370, 1826678, 1826680,
                                                1826614, 1795936, 1795938, 1795352,
                                                1794898, 1794548, 1794426, 1794428,
                                                1794378, 1794380, 1794024, 1793362,
                                                1793364, 1793218, 1793220, 1793130,
                                                1793112, 1793086, 1793088, 1792534,
                                                1792402, 1792404, 1791894, 1791846,
                                                1791654, 1791656, 1791390, 1791362,
                                                1791364, 1791036, 1790946, 1790948,
                                                1790904, 1790906, 1790898, 1790900,
                                                1790760, 1790364, 1790366, 1790196,
                                                1790198, 1790190, 1790142, 1790034,
                                                1790036, 1789974, 1789976, 1789910,
                                                1789896, 1789898, 1789734, 1789736 )) ut
                         ON up.accountid = ut.accountid
                            AND up.tickerid = ut.tickerid
          WHERE  up.id IN ( 1855377, 1854307, 1853401, 1851421, 
                            1849909, 1849911, 1849501, 1849503,
                            1849489, 1849491, 1849143, 1849141,
                            1848483, 1848485, 1846907, 1846909,
                            1845071, 1845073, 1844447, 1844449,
                            1843335, 1843337, 1842859, 1842861,
                            1842127, 1840651, 1838865, 1838863,
                            1838839, 1838841, 1838343, 1920773,
                            1918677, 1918679, 1918557, 1918509,
                            1917701, 1917543, 1917387, 1917137,
                            1916979, 1916981, 1916957, 1916955,
                            1916873, 1916751, 1916727, 1916679,
                            1916151, 1916153, 1916057, 1916009,
                            1838079, 1838081, 1838007, 1837719,
                            1837721, 1837671, 1837047, 1836685,
                            1836421, 1835009, 1834143, 1834119,
                            1826183, 1826185, 1825915, 1824601,
                            1823369, 1823275, 1823273, 1823203,
                            1823205, 1823035, 1822725, 1822723,
                            1822663, 1822483, 1822485, 1822301,
                            1821995, 1821707, 1821377, 1821173,
                            1821175, 1820957, 1820597, 1820333,
                            1820335, 1819487, 1818793, 1818791,
                            1818267, 1818269, 1817379, 1817127,
                            1816223, 1816149, 1816151, 1815955,
                            1815931, 1815583, 1815295, 1814045,
                            1813383, 1813385, 1812029, 1812027,
                            1811907, 1789319, 1789321, 1788235,
                            1787241, 1786535, 1786293, 1786295,
                            1786197, 1786199, 1785491, 1784177,
                            1784179, 1783889, 1783891, 1783711,
                            1783675, 1783625, 1783627, 1782539,
                            1782275, 1782277, 1781257, 1781161,
                            1780777, 1780779, 1780241, 1780191,
                            1780193, 1779543, 1779365, 1779363,
                            1779273, 1779275, 1779261, 1779263,
                            1778985, 1778193, 1778195, 1777851,
                            1777853, 1777839, 1777743, 1777527,
                            1777529, 1777407, 1777409, 1777277,
                            1777251, 1777253, 1776927, 1776929 );

    
    DECLARE CONTINUE HANDLER FOR NOT FOUND
            SET no_more_rows = TRUE;

    
    
    OPEN cur1;
    select FOUND_ROWS() into num_rows;
    the_loop: LOOP
        FETCH cur1 INTO c_adjustingID, c_oldDate, c_oldMilliseconds, c_badPositionID, c_newDate, c_newMilliseconds, c_auditTrailID, c_accountID, c_tickerID;

        
        
        
        IF no_more_rows THEN
           CLOSE cur1;
              LEAVE the_loop;
        END IF;

        START TRANSACTION;
        BEGIN
                
              set note = in_note;
              set description = CONCAT(in_description," Adjusting UserPosition ",c_adjustingID," so that it's ahead of UserPosition ",c_badPositionID," in time. AccountID ",c_accountID,". TickerID ",c_tickerID,".");

              select c_adjustingID, c_oldDate, c_oldMilliseconds, c_badPositionID, c_newDate, c_newMilliseconds, c_AuditTrailID, c_accountID, c_tickerID, in_performer, note, description;

              IF(in_testMode <> true) THEN
                
                IF(c_auditTrailID is null) THEN
                    insert into AuditTrails (id) values (null); set AUDIT_TRAIL_ID=LAST_INSERT_ID();
                   ELSE
                        set AUDIT_TRAIL_ID=c_auditTrailID;
                   END IF;

                   insert into AuditTasks (date,note,detail,srcIP,performerID) values (now(),note, description,"127.0.0.1",in_performer); SET AUDIT_TASK_ID:=LAST_INSERT_ID();
                   insert into AuditEvents (action,srcObject,auditTrailID,orderedCollectionIndex,auditTaskID)
                            values ('U',CONCAT("UserPosition[id=",c_adjustingID,",date=",c_oldDate,"milliseconds",c_oldMilliseconds,"]"),AUDIT_TRAIL_ID,0,AUDIT_TASK_ID);

                   
                   update UserPositions set `date` = c_newDate, milliseconds = c_newMilliseconds, auditTrailID = AUDIT_TRAIL_ID where id = c_adjustingID limit 1;
               END IF;
         COMMIT;
         END;
         
         SET loop_cntr = loop_cntr + 1;
    END LOOP the_loop;
    
    select num_rows, loop_cntr;
END;
