CREATE PROCEDURE bettermentdbtest.DequeueTradingQueueItem(IN number_of_items INT, IN requested_state VARCHAR(256))
  BEGIN

    DECLARE dequeue_id CHAR(36);
    DECLARE done INT DEFAULT 0;
    DECLARE wash_aware_legal_account_group_id BIGINT(20);
    DECLARE lock_acquired INT DEFAULT 0;


    DECLARE cur CURSOR FOR
      SELECT
        washAwareLegalAccountGroupID
      FROM TradingQueueItems tq
      WHERE tq.state = requested_state
      ORDER BY lastProcessedEpoch
      LIMIT number_of_items;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
      ROLLBACK;
      RESIGNAL;
    END;

    SET dequeue_id = UUID();



    SET lock_acquired = GET_LOCK('DequeueTradingQueueItem', 1);
    IF lock_acquired = 1
    THEN
      START TRANSACTION;

      OPEN cur;
      read_loop: LOOP
        FETCH cur
        INTO wash_aware_legal_account_group_id;
        IF done
        THEN
          LEAVE read_loop;
        END IF;

        UPDATE TradingQueueItems
        SET
          state     = 'PROCESSING',
          dequeueID = dequeue_id
        WHERE
          state = requested_state
          AND washAwareLegalAccountGroupID = wash_aware_legal_account_group_id;

      END LOOP read_loop;
      CLOSE cur;

      SELECT
        washAwareLegalAccountGroupID
      FROM TradingQueueItems tq
      WHERE tq.dequeueID = dequeue_id
      ORDER BY lastProcessedEpoch ASC;

      COMMIT;
      DO RELEASE_LOCK('DequeueTradingQueueItem');
    ELSE SELECT 1 FROM Dual WHERE 1=0;
    END IF;
  END;
