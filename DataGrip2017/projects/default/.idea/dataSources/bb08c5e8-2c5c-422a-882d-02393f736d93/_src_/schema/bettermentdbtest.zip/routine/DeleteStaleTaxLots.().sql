CREATE PROCEDURE bettermentdbtest.DeleteStaleTaxLots()
  BEGIN

    DECLARE 90_DAYS_AGO DATETIME;
    DECLARE rowcount INT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SET 90_DAYS_AGO = DATE_ADD(NOW(), INTERVAL -90 DAY);

    UPDATE TaxLots children
        INNER JOIN TaxLots parents on children.parentID = parents.id
    SET children.parentID = NULL
    WHERE parents.isCurrent = FALSE
        AND parents.hasRealizedLoss IS NOT NULL
        AND parents.sellDate < 90_DAYS_AGO;
    COMMIT;

    REPEAT
        DELETE FROM TaxLots
        WHERE isCurrent = FALSE
            AND hasRealizedLoss IS NOT NULL
            AND sellDate < 90_DAYS_AGO
        LIMIT 10000;
        SELECT ROW_COUNT() INTO rowcount;
        COMMIT;
    UNTIL rowcount = 0 END REPEAT;

    UPDATE TaxLots children
        INNER JOIN TaxLots parents on children.parentID = parents.id
    SET children.parentID = NULL
    WHERE parents.isCurrent = FALSE
        AND parents.hasRealizedLoss IS NULL
        AND parents.originalPurchaseDate < 90_DAYS_AGO
        AND parents.adjustedPurchaseDate < 90_DAYS_AGO;
    COMMIT;

    REPEAT
        DELETE FROM TaxLots
        WHERE isCurrent = FALSE
            AND hasRealizedLoss IS NULL
            AND originalPurchaseDate < 90_DAYS_AGO
            AND adjustedPurchaseDate < 90_DAYS_AGO
        LIMIT 10000;
        SELECT ROW_COUNT() INTO rowcount;
        COMMIT;
    UNTIL rowcount = 0 END REPEAT;

    COMMIT;
END;
