CREATE PROCEDURE bettermentdbtest.mapReturnTransactions(IN in_testMode TINYINT(1), IN in_performer BIGINT,
                                                        IN in_note     TEXT, IN in_description TEXT)
  BEGIN

  
  DECLARE no_more_rows BOOLEAN default FALSE;
  DECLARE loop_cntr INT DEFAULT 0;
  DECLARE num_rows INT DEFAULT 0;

  
  DECLARE initialTxnID, reversalTxnID, accountID, auditTrailID BIGINT;
  DECLARE createdDate DATETIME;
  DECLARE note, description TEXT;

  
  DECLARE AUDIT_TRAIL_ID, AUDIT_TASK_ID, TRM_ID BIGINT;

  
  
  DECLARE cur1 CURSOR FOR
  	select iut.id, rut.id, iut.accountID, rut.createdDate from UserTransactions rut
		join AuditEvents rae on rae.auditTrailID=rut.auditTrailID
		join AuditTasks rat on rat.id=rae.auditTaskID
		join UserTransactions iut on iut.id<>rut.id and iut.amount=rut.amount and iut.auditTrailID is not null
		join AuditEvents iae on iae.auditTrailID=iut.auditTrailID
		join AuditTasks iat on iat.id=iae.auditTaskID
	where rut.typeByID=16 and iut.typeByID=1
		and iat.auditTypeByID=3
		and rat.note like CONCAT("Unwinding a Deposit due to a late return for Account Account [id=",iut.accountID,", name%")
		and rat.detail like CONCAT("%UserTxn[id: ",iut.id,"; accountId: ",iut.accountID,"%")
		and NOT EXISTS (select trm.id from TransactionReversalMappings trm where trm.initialUserTransactionID=iut.id and trm.reversalUserTransactionID=rut.id)
	group by rut.id,iut.id;

  
  DECLARE CONTINUE HANDLER FOR NOT FOUND
    SET no_more_rows = TRUE;

  
  
  OPEN cur1;
  select FOUND_ROWS() into num_rows;
  START TRANSACTION;
  BEGIN
  the_loop: LOOP
		FETCH cur1 INTO initialTxnID, reversalTxnID, accountID, createdDate;

  		
      	
      	
    	IF no_more_rows THEN
        	CLOSE cur1;
       	 	LEAVE the_loop;
    	END IF;

		
    	set note = in_note;
    	set description = CONCAT(in_description, " Mapping returned debit: ",initialTxnID," to betterment's correction txn to own trades: ",reversalTxnID," as of ",createdDate," for account: ",accountID,".");
    	select initialTxnID, reversalTxnID, accountID, createdDate, in_performer, note, description;

		IF(in_testMode <> true) THEN

			
			insert into AuditTrails (id) values (null); set AUDIT_TRAIL_ID:=LAST_INSERT_ID();
			insert into AuditTasks (date,note,detail,srcIP,performerID) values (now(),note, description,"67.244.27.159",in_performer); SET AUDIT_TASK_ID:=LAST_INSERT_ID();
			insert into AuditEvents (action,srcObject,auditTrailID,orderedCollectionIndex,auditTaskID) values ('C',NULL,AUDIT_TRAIL_ID,0,AUDIT_TASK_ID);

			
			insert into TransactionReversalMappings(initialUserTransactionID,reversalUserTransactionID,createdDateTime,transactionMappingTypeID,auditTrailID)
				values(initialTxnID, reversalTxnID, createdDate,'t',AUDIT_TRAIL_ID); SET TRM_ID:=LAST_INSERT_ID();

			
			select * from TransactionReversalMappings where id=TRM_ID;
		END IF;
    	
    	SET loop_cntr = loop_cntr + 1;
	END LOOP the_loop;
	END;
	COMMIT;
	
	select num_rows, loop_cntr;
END;
