CREATE FUNCTION bettermentdbtest.subBusinessDays(startDate DATETIME, numDays INT)
  RETURNS DATETIME
  BEGIN
	DECLARE prevBDay DATETIME;
	DECLARE count INT;
	SET prevBDay = startDate;
	SET count = numDays;
	WHILE count > 0 DO
		IF isBankHolidayOrWeekend(prevBDay) = 0 THEN SET count = (count-1);
		END IF;
		SET prevBDay = DATE_SUB(prevBDay, INTERVAL 1 DAY);
	END WHILE;

	WHILE isBankHolidayOrWeekend(prevBDay) DO SET prevBDay = DATE_SUB(prevBDay, INTERVAL 1 DAY);
	END WHILE;
	RETURN prevBDay;
END;
