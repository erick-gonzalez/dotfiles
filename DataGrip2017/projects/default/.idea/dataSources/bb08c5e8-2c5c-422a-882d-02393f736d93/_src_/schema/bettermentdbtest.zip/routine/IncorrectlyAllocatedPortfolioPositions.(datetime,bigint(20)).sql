CREATE PROCEDURE bettermentdbtest.IncorrectlyAllocatedPortfolioPositions(IN queryDate        DATETIME,
                                                                         IN omnibusAccountID BIGINT)
  BEGIN

    
    DROP TEMPORARY TABLE IF EXISTS tmp_validAccts;
    CREATE TEMPORARY TABLE tmp_validAccts
    SELECT ac.id AS accountID
    FROM Accounts ac
    INNER JOIN AccountGroups ag ON ac.accountGroupID = ag.id
    WHERE ag.isDemo = 0
    AND ac.omnibusAccountID = omnibusAccountID;

    
    ALTER TABLE tmp_validAccts ADD INDEX(accountID);

    
    DROP TEMPORARY TABLE IF EXISTS tmp_allRelevantTxns;
    CREATE TEMPORARY TABLE tmp_allRelevantTxns
    SELECT ut.id, ut.accountID, ut.completedDate, ut.milliseconds
    FROM UserTransactions ut
    INNER JOIN tmp_validAccts va ON ut.accountID = va.accountID
    INNER JOIN TransactionPortfolios tp ON tp.transactionID = ut.id
    WHERE ut.completedDate <= queryDate;

    
    ALTER TABLE tmp_allRelevantTxns ADD INDEX (accountID, completedDate);

    
    DROP TEMPORARY TABLE IF EXISTS tmp_lastTxn;
    CREATE TEMPORARY TABLE tmp_lastTxn
    SELECT accountID, MAX(completedDate) AS maxDate
    FROM tmp_allRelevantTxns
    GROUP BY accountID;

    
    ALTER TABLE tmp_lastTxn ADD INDEX (accountID, maxDate);

    
    DROP TEMPORARY TABLE IF EXISTS tmp_latestTxnId;
    CREATE TEMPORARY TABLE tmp_latestTxnId
    SELECT
    ut2.id,
    ut2.accountID,
    ut2.completedDate,
    MAX(ut2.milliseconds) AS maxMillis
    FROM tmp_allRelevantTxns ut2
    JOIN tmp_lastTxn AS l1 ON l1.accountID = ut2.accountID AND l1.maxDate = ut2.completedDate
    GROUP BY ut2.accountID, ut2.completedDate;

    
    ALTER TABLE tmp_latestTxnId ADD INDEX(id);

    
    
    DROP TEMPORARY TABLE IF EXISTS tmp_intendedComponents;
    CREATE TEMPORARY TABLE tmp_intendedComponents
    SELECT ltid.accountID, ca.componentID, cn.tickerID
    FROM TransactionPortfolios tp
    INNER JOIN ComponentAllocations ca ON ca.portfolioID = tp.portfolioID
    INNER JOIN ComponentNews cn ON cn.id = ca.componentID
    INNER JOIN tmp_latestTxnId ltid ON ltid.id=tp.transactionID;

    
    ALTER TABLE tmp_intendedComponents ADD INDEX(accountID, componentID);

    
    DROP TEMPORARY TABLE IF EXISTS tmp_latestPositions;
    CREATE TEMPORARY TABLE tmp_latestPositions
    SELECT
      up.*
    FROM UserPositions up
    JOIN (
          SELECT
          up2.accountID,
                up2.tickerID,
                up2.date,
                MAX(up2.milliseconds) AS maxMillis
          FROM UserPositions up2
          JOIN (
                SELECT upi.accountID, upi.tickerID, MAX(upi.DATE) AS maxDate
                FROM UserPositions upi
                INNER JOIN tmp_validAccts va
                ON upi.accountID = va.accountID
                WHERE DATE <= queryDate
                GROUP BY upi.accountID, upi.tickerID
                ) AS l1
            ON l1.accountID = up2.accountID
            AND l1.tickerID = up2.tickerID
            AND l1.maxDate = up2.date
          GROUP BY up2.accountID, up2.tickerID, up2.date
          ) AS l2
      ON l2.accountID = up.accountID
      AND l2.tickerID = up.tickerID
      AND l2.date = up.date
      AND l2.maxMillis = up.milliseconds
    WHERE up.shares > 0;

    
    ALTER TABLE tmp_latestPositions ADD INDEX(accountID, tickerID);

    
    SELECT lp.*
    FROM tmp_latestPositions lp
    LEFT JOIN tmp_intendedComponents ic ON lp.accountID = ic.accountID AND ic.tickerID = lp.tickerID
    WHERE ic.componentID IS NULL;

    DROP TEMPORARY TABLE IF EXISTS tmp_latestPositions;
    DROP TEMPORARY TABLE IF EXISTS tmp_intendedComponents;
    DROP TEMPORARY TABLE IF EXISTS tmp_latestTxnId;
    DROP TEMPORARY TABLE IF EXISTS tmp_lastTxn;
    DROP TEMPORARY TABLE IF EXISTS tmp_validAccts;
    DROP TEMPORARY TABLE IF EXISTS tmp_allRelevantTxns;

END;
