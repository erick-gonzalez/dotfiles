CREATE TRIGGER bettermentdbtest.AggregateB4bTransactions_after_ins_trig
AFTER INSERT ON bettermentdbtest.Aggregate401kContributions
FOR EACH ROW
  BEGIN
  INSERT INTO AggregateB4bTransactions (
    id,
    achTransactionID,
    wireTransactionID,
    failedDateTime,
    last_modified_datetime
  )
  VALUES (
    new.id,
    new.achTransactionID,
    new.wireTransactionID,
    new.failedDateTime,
    new.last_modified_datetime
  );
END;
