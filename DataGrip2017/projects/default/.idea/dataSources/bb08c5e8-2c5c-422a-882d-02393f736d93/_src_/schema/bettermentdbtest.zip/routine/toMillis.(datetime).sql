CREATE FUNCTION bettermentdbtest.toMillis(inDateTime DATETIME)
  RETURNS BIGINT
  BEGIN
    DECLARE toMillis BIGINT;
    SET toMillis = UNIX_TIMESTAMP(inDateTime)*1000;
    RETURN toMillis;
END;
