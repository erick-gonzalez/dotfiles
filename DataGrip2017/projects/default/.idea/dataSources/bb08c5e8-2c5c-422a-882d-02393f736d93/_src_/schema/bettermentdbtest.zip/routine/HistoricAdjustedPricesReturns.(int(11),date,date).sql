CREATE PROCEDURE bettermentdbtest.HistoricAdjustedPricesReturns(IN ticker INT, IN fromDate DATE, IN toDate DATE)
  BEGIN
set @count2=0, @count1=0, @cum=1.0, @id=0;
set @prevDate = (select h.date from HistoricAdjustedPrices h where h.date < fromDate order by h.date desc limit 1);
select h1.date, if(h1.date=fromDate, 0.0, (h1.price/h2.price)-1.0) incrementalReturn, (@cum:=if(h1.date=fromDate, 1.0, @cum*(h1.price/h2.price)))-1.0 cumulativeReturn from
(select date, price, @count1:=@count1+1 count1 from HistoricAdjustedPrices where date >= fromDate and date <= toDate and tickerId=ticker order by date) h1 join 
(select date, price, @count2:=@count2+1 count2 from HistoricAdjustedPrices where date >= @prevDate and date <= DATE_SUB(toDate, INTERVAL 1 DAY) and tickerId=ticker order by date) h2 
where count1=count2;
END;
