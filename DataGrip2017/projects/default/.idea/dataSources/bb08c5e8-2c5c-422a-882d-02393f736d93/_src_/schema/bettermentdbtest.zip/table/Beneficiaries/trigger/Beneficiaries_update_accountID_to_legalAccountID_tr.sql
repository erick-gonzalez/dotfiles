CREATE TRIGGER bettermentdbtest.Beneficiaries_update_accountID_to_legalAccountID_tr
BEFORE UPDATE ON bettermentdbtest.Beneficiaries
FOR EACH ROW
  BEGIN
    IF (NEW.accountGroupID IS NOT NULL) THEN
        SET NEW.legalAccountID = (SELECT legalAccountID FROM Accounts WHERE accountGroupID = NEW.accountGroupID AND accountType = 'INVESTING' LIMIT 1);
    END IF;

    IF (NEW.accountID IS NOT NULL) THEN
        SET NEW.legalAccountID = (SELECT legalAccountID FROM Accounts where id = NEW.accountID);
    END IF;
END;
