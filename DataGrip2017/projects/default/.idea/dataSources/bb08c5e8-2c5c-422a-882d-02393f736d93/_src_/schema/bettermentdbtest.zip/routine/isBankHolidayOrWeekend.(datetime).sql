CREATE FUNCTION bettermentdbtest.isBankHolidayOrWeekend(input DATETIME)
  RETURNS BIT
  BEGIN
    DECLARE dayOfWeek INT DEFAULT 0;
    DECLARE result BIT DEFAULT false;
    DECLARE holidayCount INT DEFAULT 0;
    SET dayOfWeek = DAYOFWEEK(input);
    SELECT COUNT(*) FROM SignificantDates WHERE type = 'BANK_HOLIDAY' AND significantDate = DATE(input) INTO holidayCount;
    IF dayOfWeek = 7 or dayOfWeek = 1 or holidayCount > 0 THEN SET result = true;
    END IF;
RETURN result;
END;
