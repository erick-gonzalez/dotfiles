CREATE PROCEDURE bettermentdbtest.SnapshotGoalProjections()
  BEGIN
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION ROLLBACK;  
    START TRANSACTION;      

    INSERT INTO HistoricGoalProjections 
    	(id  , accountId, status, targetBalance, currentBalance, projectedBalance, recoMonthly, currMonthly, recoOneTime, remainingTerm, recoAllocation, currAllocation, recoTerm)
    SELECT 
         null, accountId, status, targetBalance, currentBalance, projectedBalance, recoMonthly, currMonthly, recoOneTime, remainingTerm, recoAllocation, currAllocation, recoTerm
    FROM GoalProjections 
    ORDER BY accountID;

    COMMIT;             
END;
